package com.lxy.activity;

import java.util.ArrayList;
import java.util.List;

import com.lxy.passwordview.R;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnKeyListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends Activity {

	private EditText pwd1, pwd2, pwd3, pwd4, pwd5, pwd6;
	private Button begin_bn;
	private List<EditText> list = new ArrayList<EditText>();
	// 标志位,delete 事件每次点击后只执行一次
	private int type = 0;
	private StringBuffer line;

	// 标志位,如果删除的是最后一位密码,只删除此位置数字
	private Boolean flag = false;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		initView();
	}

	private void initView() {
		// TODO Auto-generated method stub
		pwd1 = (EditText) findViewById(R.id.pwd_et_6_1);
		pwd2 = (EditText) findViewById(R.id.pwd_et_6_2);
		pwd3 = (EditText) findViewById(R.id.pwd_et_6_3);
		pwd4 = (EditText) findViewById(R.id.pwd_et_6_4);
		pwd5 = (EditText) findViewById(R.id.pwd_et_6_5);
		pwd6 = (EditText) findViewById(R.id.pwd_et_6_6);

		list.add(pwd1);
		list.add(pwd2);
		list.add(pwd3);
		list.add(pwd4);
		list.add(pwd5);
		list.add(pwd6);
		for (int i = 0; i < list.size(); i++) {
			list.get(i).addTextChangedListener(watcher);
			list.get(i).setOnKeyListener(delete);
		}

	}

	OnKeyListener delete = new OnKeyListener() {

		@Override
		public boolean onKey(View v, int keyCode, KeyEvent event) {
			// TODO Auto-generated method stub
			if (type == 1) {
				type = 0;
				if (keyCode == KeyEvent.KEYCODE_DEL) {
					Log.e("lxy", "按下去");
					int done_delete_id = getCurrentFocus().getId();
					for (int i = list.size() - 1; i > 0; i--) {
						if (list.get(i).getId() == done_delete_id) {
							int before_index = i - 1;
							Log.e("lxy", "size=" + list.size());
							Log.e("lxy", "i=" + i);
							if (i == 5 && flag == true) {
								list.get(i).setText(null);
								list.get(i).setFocusableInTouchMode(true);
								list.get(i).setFocusable(true);
								list.get(i).requestFocus();
								i = i - 1;
								flag = false;
								break;
							} else {
								try {
									EditText before_edit = list
											.get(before_index);
									before_edit.setFocusableInTouchMode(true);
									before_edit.setFocusable(true);
									before_edit.requestFocus();
									before_edit.setText(null);
									list.get(i).setFocusable(false);
								} catch (Exception e) {

								}
							}
						}
					}
				}
			} else {
				type = 1;
			}

			return false;
		}
	};

	TextWatcher watcher = new TextWatcher() {

		@Override
		public void onTextChanged(CharSequence s, int start, int before,
				int count) {
			// TODO Auto-generated method stub
			if (s.length() == 1) {
				int done_input_id = getCurrentFocus().getId();
				for (int i = 0; i < list.size(); i++) {
					if (list.get(i).getId() == done_input_id) {
						int next_index = i + 1;
						if (i == 5) {
							// Intent intent = new Intent(
							// JoinByPaswordActivity.this,
							// LoginActivity.class);
							// startActivity(intent);
							flag = true;
							InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
							imm.hideSoftInputFromWindow(pwd6.getWindowToken(),
									0);
							return;

						}
						try {

							EditText next_edit = list.get(next_index);
							next_edit.setFocusableInTouchMode(true);
							next_edit.setFocusable(true);
							next_edit.requestFocus();
							list.get(i).setFocusable(false);
						} catch (Exception e) {

						}
					}
				}
			}

		}

		@Override
		public void beforeTextChanged(CharSequence s, int start, int count,
				int after) {
			// TODO Auto-generated method stub

		}

		@Override
		public void afterTextChanged(Editable s) {
			// TODO Auto-generated method stub

		}
	};

}